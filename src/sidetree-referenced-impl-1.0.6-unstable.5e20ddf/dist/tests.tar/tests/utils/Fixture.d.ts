export default class Fixture {
    private static writeFixtureToDisk;
    static fixtureDriftHelper(received: any, expected: any, pathToFixture: string, overwrite?: boolean): void;
}
