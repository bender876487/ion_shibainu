"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const timeSpan = require("time-span");
const DownloadManager_1 = require("../../lib/core/DownloadManager");
const Logger_1 = require("../../lib/common/Logger");
const MockCas_1 = require("../mocks/MockCas");
describe('DownloadManager', () => __awaiter(void 0, void 0, void 0, function* () {
    const maxConcurrentDownloads = 3;
    const mockSecondsTakenForEachCasFetch = 2;
    let cas;
    let downloadManager;
    const originalDefaultTestTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    describe('constructor', () => {
        it('should use default values if maxConcurrentDownloads is NaN', () => {
            const testDownloadManager = new DownloadManager_1.default(undefined, new MockCas_1.default(mockSecondsTakenForEachCasFetch));
            expect(testDownloadManager['maxConcurrentDownloads']).toEqual(20);
        });
    });
    describe('start', () => {
        beforeEach(() => {
            // Freeze time
            jasmine.clock().install();
        });
        afterEach(() => {
            // Unfreeze time
            jasmine.clock().uninstall();
        });
        it('should log error and restart the timer if an error is thrown within start', () => {
            const loggerErrorSpy = spyOn(Logger_1.default, 'error');
            cas = new MockCas_1.default(mockSecondsTakenForEachCasFetch);
            downloadManager = new DownloadManager_1.default(maxConcurrentDownloads, cas);
            downloadManager['activeDownloads'] = 1; // intentionally set to a bad type so it will throw
            downloadManager.start();
            expect(loggerErrorSpy).toHaveBeenCalled();
        });
    });
    describe('download', () => {
        beforeAll(() => {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = 20000; // These asynchronous tests can take a bit longer than normal.
            cas = new MockCas_1.default(mockSecondsTakenForEachCasFetch);
            downloadManager = new DownloadManager_1.default(maxConcurrentDownloads, cas);
            downloadManager.start();
        });
        afterAll(() => {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = originalDefaultTestTimeout;
        });
        it('should queue up downloads if max concurrent download count is exceeded.', () => __awaiter(void 0, void 0, void 0, function* () {
            // Write some content in CAS.
            const content1 = yield cas.write(Buffer.from('1'));
            const content2 = yield cas.write(Buffer.from('2'));
            const content3 = yield cas.write(Buffer.from('3'));
            const content4 = yield cas.write(Buffer.from('4'));
            // Start timer to measure total time taken for the 4 downloads.
            const endTimer = timeSpan();
            // Queue 4 downloads.
            const maxContentSizeInBytes = 20000000;
            downloadManager.download(content1, maxContentSizeInBytes);
            downloadManager.download(content2, maxContentSizeInBytes);
            downloadManager.download(content3, maxContentSizeInBytes);
            yield downloadManager.download(content4, maxContentSizeInBytes);
            // Since there is only 3 concurrent download lanes,
            // the 4th download would have to wait thus download time would be at least twice the time as the mock download time.
            const totalDownloadTimeInMs = endTimer.rounded();
            const minimalTimeTakenInMs = mockSecondsTakenForEachCasFetch * 2 * 1000;
            expect(totalDownloadTimeInMs).toBeGreaterThanOrEqual(minimalTimeTakenInMs);
        }));
    });
    describe('downloadAsync', () => {
        beforeEach(() => {
            // Freeze time
            jasmine.clock().install();
            cas = new MockCas_1.default(mockSecondsTakenForEachCasFetch);
            downloadManager = new DownloadManager_1.default(maxConcurrentDownloads, cas);
        });
        afterEach(() => {
            // Unfreeze time
            jasmine.clock().uninstall();
        });
        it('should log error if CAS read throws', () => {
            spyOn(cas, 'read').and.throwError('expected test error');
            const loggerErrorSpy = spyOn(Logger_1.default, 'error');
            downloadManager['downloadAsync']({});
            expect(loggerErrorSpy).toHaveBeenCalled();
        });
    });
}));
//# sourceMappingURL=DownloadManager.spec.js.map