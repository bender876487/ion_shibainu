"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * test version of throughput limiter
 */
class TransactionSelector {
    selectQualifiedTransactions(_transactions) {
        return new Promise((resolve) => { resolve([]); });
    }
}
exports.default = TransactionSelector;
//# sourceMappingURL=TransactionSelector.js.map